
//The variable holds reference to the object with class clock to manipulate its style and attach events to it.
const clock_element=document.querySelector(".clock")
const buttons=document.querySelectorAll(".format button")
let format='24';
function Generate_current_time() {
  clock_element.getAttribute("data-format");
  const now = new Date();
  let h = now.getHours();
  let m = now.getMinutes();
  let s = now.getSeconds();
  let period = h >= 12 ? 'PM' : 'AM';
  h = h < 10 ? '0' + h : h;
  m = m < 10 ? '0' + m : m;
  s = s < 10 ? '0' + s : s;
  if (format === "12") {
    h = h > 12 ? "0"+h % 12 : h;
    h = h === 0 ? 12 : h;
  }
  document.getElementById("hours").textContent = h;
  document.getElementById("minutes").textContent = m;
  document.getElementById("seconds").textContent = s;
  document.getElementById("period").textContent = period;
}
buttons.forEach((button) => {
  button.addEventListener("click", () => {
    format = button.getAttribute("data-format"); 
    Generate_current_time();
  });
});

setInterval(Generate_current_time, 1000);
Generate_current_time();

