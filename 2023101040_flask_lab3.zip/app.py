from flask import Flask, request, render_template, jsonify
from cryptography.fernet import Fernet
import json
import os
import uuid

app = Flask(__name__)

key = Fernet.generate_key()
f = Fernet(key)

@app.route("/", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        un = request.form['name']
        em = request.form['email']
        pw = request.form['password']
        fernet_token = f.encrypt(pw.encode())
        if os.path.exists("users.txt"):
            with open("users.txt", "r") as file:
                try:
                    data = json.load(file)
                except json.JSONDecodeError:
                    data = {}
        else:
            data = {}
        for user_info in data.values():
            if user_info['email'] == em:
                return "Registration did not occur. User with the same ID already exists."

        user_info = {'name': un, 'email': em, 'password': fernet_token.decode()}
        user_id = str(uuid.uuid4())
        data[user_id] = user_info 
        with open("users.txt", "w") as file:
            json.dump(data, file, indent=4)
        
        return "Congratulations! You have been registered."
    else:
        return render_template("register.html")

@app.route("/user/<user_id>")
def user(user_id):
    if os.path.exists("users.txt"):
        with open("users.txt", "r") as file:
            try:
                data = json.load(file)
            except json.JSONDecodeError:
                return "Users file not found or in invalid format.", 500
    else:
        return "User details file not found.", 404
    for user_email, user_info in data.items():
        if user_info['email'] == user_id:
            user_info['password'] = f.decrypt(user_info['password'].encode()).decode('utf-8')
            return jsonify(user_info)
    
    return "Invalid: User ID not found.", 404

if __name__ == '__main__':
    app.run(debug=True)
