If the user has to check for registration details based on ID, the input must be given in the URL in this format:
http://127.0.0.1:5000/user/rani@gmail.com
This is given that the email of the user is rani@gmail.com.

I have done a few things:
1. The will not be allowed to register with the same email ID more than once. Within the register function, a loop runs through all values in the data dictionary. I if any of the user_info have an email key that mathces the provided email, an error message is sent that the registration did not occur. The users.txt file is not updated.
2.If the user enetrs an invalid username, an error meaage indicating that the uuser ID is invalid shows up.